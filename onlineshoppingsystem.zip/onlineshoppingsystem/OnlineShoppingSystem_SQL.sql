CREATE DATABASE trenderstest; 

USE trenderset; 

CREATE TABLE `signup` (
  `UserName` varchar(45) NOT NULL,
  `Password` varchar(45) DEFAULT NULL,
  `FullName` varchar(45) DEFAULT NULL,
  `Email` varchar(45) DEFAULT NULL,
  `Mobile` varchar(45) DEFAULT NULL,
  `Address` varchar(45) DEFAULT NULL,
  `City` varchar(45) DEFAULT NULL,
  `ZIP` varchar(45) DEFAULT NULL,
  `UserModule` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`UserName`)
);
INSERT INTO `signup` VALUES ('adminname','admin','adminname','email','mobile','address','city','zip','Admin'),('customername','customer','customername','email','1745289369','address','city','zip','Customer'),('customername1','customer1','customername1','email','1745289369','address','city','zip','Customer'),('customername2','customer2','customername2','email','1745289369','address','city','zip','Customer');



CREATE TABLE `productslist` (
  `ProductName` varchar(45) NOT NULL,
  `Classification` varchar(45) DEFAULT NULL,
  `Price` varchar(45) DEFAULT NULL,
  `Size` varchar(45) DEFAULT NULL,
  `Specifications` varchar(45) DEFAULT NULL,
  `StockCount` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`ProductName`)
);

INSERT INTO `productslist` VALUES ('product1','class1','1000','size1','specification1','1000'),('product2','class2','500','size2','specification2','500'),('product3','class3','1000','size3','specification3','1000');


CREATE TABLE `customerbag` (
  `bagid` int(11) NOT NULL AUTO_INCREMENT,
  `ProductName` varchar(45) DEFAULT NULL,
  `Classification` varchar(45) DEFAULT NULL,
  `Price` varchar(45) DEFAULT NULL,
  `Size` varchar(45) DEFAULT NULL,
  `Specifications` varchar(45) DEFAULT NULL,
  `QuantityRequired` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`bagid`)
);

INSERT INTO `customerbag` VALUES (6,'product1\r\n','class1\r\n','1000\r\n','size1\r\n','specification1\r\n','12'),(7,'product3\r\n','class3\r\n','1000\r\n','size3\r\n','specification3\r\n','10');


CREATE TABLE `customerorders` (
  `OrderID` int(11) NOT NULL AUTO_INCREMENT,
  `TotalPrice` varchar(45) DEFAULT NULL,
  `Mobile` varchar(45) DEFAULT NULL,
  `ShippingAddress` varchar(45) DEFAULT NULL,
  `CardNumber` varchar(45) DEFAULT NULL,
  `ExpirationDate` varchar(45) DEFAULT NULL,
  `CVCode` varchar(45) DEFAULT NULL,
  `CustomerName` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`OrderID`)
);

INSERT INTO `customerorders` VALUES (2,'null','mobile','address','12341234','12-12-21','1234','customername'),(3,'null','12341234213','address','12341234','12-12-21','1234','customername1'),(4,'null','2141242','address','12341234','12-12-21','1234','customername2');


CREATE TABLE `queries` (
  `QueryID` int(11) NOT NULL AUTO_INCREMENT,
  `CustomerName` varchar(45) DEFAULT NULL,
  `Email` varchar(45) DEFAULT NULL,
  `Mobile` varchar(45) DEFAULT NULL,
  `Query` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`QueryID`)
);


INSERT INTO `queries` VALUES (5,'customer','customer@gmail.com','1341234234','hello'),(6,'customer1','customer1@gmail.com','41243','hi'),(7,'customer3','customer3@gmail.com','53451234','Hello');

