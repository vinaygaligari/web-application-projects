CREATE DATABASE patientcommunity;

USE patientcommunity; 

CREATE TABLE `communitypost` (
  `communitypostid` int(11) NOT NULL AUTO_INCREMENT,
  `community` varchar(45) DEFAULT NULL,
  `post` varchar(45) DEFAULT NULL,
  `sendername` varchar(45) DEFAULT NULL,
  `response` varchar(45) DEFAULT NULL,
  `responseby` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`communitypostid`)
);

CREATE TABLE `messages` (
  `messageid` int(11) NOT NULL AUTO_INCREMENT,
  `community` varchar(45) DEFAULT NULL,
  `message` varchar(45) DEFAULT NULL,
  `reply` varchar(45) DEFAULT NULL,
  `username` varchar(45) DEFAULT NULL,
  `loginuser` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`messageid`)
);


CREATE TABLE `patients` (
  `username` varchar(45) NOT NULL,
  `password` varchar(45) DEFAULT NULL,
  `fullname` varchar(45) DEFAULT NULL,
  `gender` varchar(45) DEFAULT NULL,
  `dob` varchar(45) DEFAULT NULL,
  `community` varchar(45) DEFAULT NULL,
  `phone` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`username`)
);


CREATE TABLE `recommendations` (
  `recommendationsid` int(11) NOT NULL AUTO_INCREMENT,
  `recommenddrugs` varchar(45) DEFAULT NULL,
  `recommendsupplements` varchar(45) DEFAULT NULL,
  `recommendtreatment` varchar(45) DEFAULT NULL,
  `recommenddoctor` varchar(45) DEFAULT NULL,
  `recommendhealthcare` varchar(45) DEFAULT NULL,
  `addtips` varchar(45) DEFAULT NULL,
  `community` varchar(45) DEFAULT NULL,
  `username` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`recommendationsid`)
); 
