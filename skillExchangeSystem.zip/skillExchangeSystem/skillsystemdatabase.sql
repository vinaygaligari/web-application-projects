DROP DATABASE IF EXISTS skillsystemdatabase;
CREATE DATABASE skillsystemdatabase;
USE skillsystemdatabase; 


CREATE TABLE `signup` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `FullName` varchar(255) NOT NULL,
  `Mobile` varchar(15) NOT NULL,
  `Email` varchar(255) NOT NULL,
  `UserType` varchar(50) NOT NULL,
  `UserName` varchar(50) NOT NULL,
  `Password` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
);

CREATE TABLE `skillprofile` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `skillName` varchar(255) NOT NULL,
  `skillType` varchar(255) NOT NULL,
  `proficiency` varchar(50) DEFAULT NULL,
  `description` text,
  `UserName` varchar(50) DEFAULT NULL,
  `Contact` varchar(15) DEFAULT NULL,
  PRIMARY KEY (`id`)
);

CREATE TABLE `skillrequest` (
  `RequestID` int(11) NOT NULL AUTO_INCREMENT,
  `SkillRequested` varchar(50) NOT NULL,
  `SkillDetails` varchar(255) DEFAULT NULL,
  `RequestMessage` text,
  `Status` varchar(20) DEFAULT 'Pending',
  `AssignedPerson` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`RequestID`)
);

CREATE TABLE `workshops` (
  `WorkshopID` int(11) NOT NULL AUTO_INCREMENT,
  `Title` varchar(255) NOT NULL,
  `Date` date NOT NULL,
  `TimeStart` time NOT NULL,
  `TimeEnd` time NOT NULL,
  `Details` text,
  PRIMARY KEY (`WorkshopID`)
); 

INSERT INTO `workshops` VALUES (1,'Cooking Masterclass','2023-01-15','15:00:00','17:00:00','Join us for a hands-on cooking experience.'),(2,'Gardening Basics','2023-01-22','14:00:00','16:00:00','Learn the essentials of gardening and plant care.');
