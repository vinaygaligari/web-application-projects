DROP DATABASE IF EXISTS wastemanager_records;

CREATE DATABASE wastemanager_records;

USE wastemanager_records; 


CREATE TABLE claims (
  claim_id int(11) NOT NULL AUTO_INCREMENT,
  food_id int(11) NOT NULL,
  user_name varchar(255) NOT NULL,
  required_quantity int(11) NOT NULL,
  desired_price decimal(10,2) NOT NULL,
  claim_date timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (claim_id)
);

CREATE TABLE food_donation_requests (
  request_id int(11) NOT NULL AUTO_INCREMENT,
  charity_name varchar(255) NOT NULL,
  contact_person varchar(255) NOT NULL,
  email varchar(255) NOT NULL,
  location varchar(255) NOT NULL,
  number_of_persons int(11) NOT NULL,
  description text NOT NULL,
  request_date timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (request_id)
);

CREATE TABLE leftover_food_items (
  id int(11) NOT NULL AUTO_INCREMENT,
  food_name varchar(255) NOT NULL,
  description text NOT NULL,
  restaurant varchar(255) NOT NULL,
  location varchar(255) NOT NULL,
  quantity_available int(11) NOT NULL,
  expiry_date date NOT NULL,
  expiry_time time NOT NULL,
  original_price decimal(10,2) NOT NULL,
  PRIMARY KEY (id)
);

CREATE TABLE messages (
  id int(11) NOT NULL AUTO_INCREMENT,
  restaurant_id int(11) NOT NULL,
  sender_username varchar(100) NOT NULL,
  subject varchar(255) NOT NULL,
  message_text text NOT NULL,
  message_date timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id)
);

CREATE TABLE restaurants (
  restaurant_id int(11) NOT NULL AUTO_INCREMENT,
  restaurant_name varchar(255) NOT NULL,
  owner_name varchar(255) NOT NULL,
  email varchar(255) NOT NULL UNIQUE,
  password varchar(255) NOT NULL,
  contact varchar(15) NOT NULL,
  address varchar(255) NOT NULL,
  cuisine_type varchar(100) NOT NULL,
  PRIMARY KEY (restaurant_id)
);

CREATE TABLE users (
  id int(11) NOT NULL AUTO_INCREMENT,
  fullname varchar(100) NOT NULL,
  email varchar(100) NOT NULL UNIQUE,
  password varchar(255) NOT NULL,
  mobile varchar(15) NOT NULL,
  userType enum('restaurant','charity user') NOT NULL,
  created_at timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id)
);


INSERT INTO users (fullname, email, password, mobile, userType)
VALUES
    ('Elmo Williams', 'elmo_williams28@yahoo.com', 'Elmo@1234', '555-0143', 'charity user'),
    ('Leona Moses', 'leona_moses21@yahoo.com', 'Leona@5678', '555-0144', 'charity user'),
    ('Kristine Herrera', 'kristine_herrera47@yahoo.com', 'Kristine@9101', '555-0145', 'charity user');

INSERT INTO restaurants (restaurant_name, owner_name, email, password, contact, address, cuisine_type)
VALUES
    ('Green Eats', 'Melanie Sherman', 'melanie-sherman25@mail.com', 'GreenEats@456', '555-0146', '123 Healthy Ave, Wellness City', 'Vegan'),
    ('Sunrise Diner', 'Palmer Aguirre', 'palmer_aguirre27@aol.com', 'Sunrise@789', '555-0147', '456 Breakfast Blvd, Sunnyville', 'American'),
    ('Taste of India', 'Moises Clay', 'moises_clay24@outlook.com', 'TasteIndia@123', '555-0148', '789 Curry Rd, Spice Town', 'Indian');

INSERT INTO leftover_food_items (food_name, description, restaurant, location, quantity_available, expiry_date, expiry_time, original_price)
VALUES
    ('Grilled Vegetables', 'A mix of grilled seasonal vegetables.', 'Green Eats', 'Wellness City', 20, '2024-11-02', '14:00:00', 50.00),
    ('Pancakes', 'Fluffy pancakes with syrup.', 'Sunrise Diner', 'Sunnyville', 10, '2024-11-02', '10:00:00', 30.00),
    ('Chicken Curry', 'Spicy chicken curry with Indian spices.', 'Taste of India', 'Spice Town', 15, '2024-11-02', '20:00:00', 75.00);

INSERT INTO claims (food_id, user_name, required_quantity, desired_price)
VALUES
    (1, 'Elmo Williams', 5, 25.00),
    (2, 'Leona Moses', 3, 15.00),
    (3, 'Kristine Herrera', 7, 45.00);

INSERT INTO food_donation_requests (charity_name, contact_person, email, location, number_of_persons, description)
VALUES
    ('Helping Hands', 'Christine Ballard', 'christine_ballard15@aol.com', 'Downtown', 30, 'Requesting food for local homeless shelter.'),
    ('Food for All', 'Colleen Fernandez', 'colleen-fernandez40@mail.com', 'City Center', 50, 'Seeking meal donations for low-income families.'),
    ('Nourish Neighbors', 'Shelby Schneider', 'shelby_schneider26@aol.com', 'East End', 20, 'In need of non-perishable and leftover food items.');

INSERT INTO messages (restaurant_id, sender_username, subject, message_text)
VALUES
    (1, 'Keneth Paul', 'Leftover Donation Inquiry', 'Could we discuss regular donations for our evening shelter program?'),
    (2, 'Colleen Fernandez', 'Request for Breakfast Donations', 'Looking to partner with you for weekly pancake donations.'),
    (3, 'Shelby Schneider', 'Food Availability Check', 'Would love to claim any unsold meals or ingredients.');

