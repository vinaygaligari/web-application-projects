DROP DATABASE IF EXISTS crmsystemdb;
CREATE DATABASE crmsystemdb;
USE crmsystemdb; 

-- Create tables 
CREATE TABLE broadcast_messages (
  message_id int(11) NOT NULL AUTO_INCREMENT,
  subject varchar(255) NOT NULL,
  message_body text NOT NULL,
  sent_date datetime NOT NULL,
  notes text,
  message_type enum('Announcement','Reminder','Update') NOT NULL,
  customer_segment enum('All','New','Returning','VIP') NOT NULL,
  PRIMARY KEY (message_id)
);

CREATE TABLE customers (
  customer_id int(11) NOT NULL AUTO_INCREMENT,
  first_name varchar(50) NOT NULL,
  last_name varchar(50) NOT NULL,
  email varchar(100) NOT NULL,
  mobile varchar(20) NOT NULL,
  address varchar(255) NOT NULL,
  notes text,
  registration_date timestamp NOT NULL,
  PRIMARY KEY (customer_id)
);

CREATE TABLE customer_complaints (
  complaint_id int(11) NOT NULL AUTO_INCREMENT,
  customer_id int(11) NOT NULL,
  complaint_subject varchar(255) NOT NULL,
  complaint_description text NOT NULL,
  complaint_date timestamp NOT NULL,
  status enum('Pending','Resolved','Closed') DEFAULT 'Pending',
  assigned_employee varchar(255),
  notes text,
  PRIMARY KEY (complaint_id)
);

CREATE TABLE messages (
  message_id int(11) NOT NULL AUTO_INCREMENT,
  sender_id int(11) NOT NULL,
  customer_id int(11) NOT NULL,
  subject varchar(255) NOT NULL,
  message_body text NOT NULL,
  sent_date timestamp NOT NULL,
  PRIMARY KEY (message_id)
);

CREATE TABLE tickets (
  ticket_id int(11) NOT NULL AUTO_INCREMENT,
  customer_id int(11) NOT NULL,
  subject varchar(255) NOT NULL,
  description text NOT NULL,
  priority enum('Low','Medium','High') NOT NULL,
  status enum('Open','In Progress','Closed') NOT NULL,
  assigned_employee varchar(255),
  created_at timestamp NOT NULL,
  PRIMARY KEY (ticket_id)
);

CREATE TABLE users (
  id int(11) NOT NULL AUTO_INCREMENT,
  username varchar(50) NOT NULL,
  password varchar(255) NOT NULL,
  mobile varchar(20) NOT NULL,
  email varchar(100) NOT NULL,
  user_type ENUM('admin', 'employee', 'customer') NOT NULL, 
  registration_date timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY username (username),
  UNIQUE KEY email (email)
);


CREATE TABLE ticket_feedback (
  feedback_id INT(11) NOT NULL AUTO_INCREMENT,
  ticket_id INT(11) NOT NULL,
  feedback TEXT NOT NULL,
  rating INT(1) CHECK (rating >= 1 AND rating <= 5),
  feedback_date TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (feedback_id)
);



-- Insert data into tables
-- Insert records into customers table
INSERT INTO customers (customer_id, first_name, last_name, email, mobile, address, notes, registration_date) 
VALUES 
(196, 'Jenifer', 'Harris', 'jenifer.harris@yahoo.com', '555-321-9876', '123 Maple St, Springfield', NULL, '2024-09-10 09:30:00'),
(485, 'Rosella', 'Rice', 'rosella.rice@hotmail.com', '555-654-1234', '789 Birch Ave, Springfield', 'VIP customer', '2024-09-11 10:15:00');

-- Insert records into users table
-- Insert records into users table
INSERT INTO users (id, username, password, mobile, email, user_type, registration_date) 
VALUES 
(192, 'admin_user', 'admin123', '555-111-2222', 'admin@hotmail.com', 'admin', '2024-09-10 09:30:00'),
(265, 'employee_user', 'employee123', '555-444-5555', 'employee@gmail.com', 'employee', '2024-09-11 10:15:00'),
(380, 'customer_user', 'customer123', '555-777-8888', 'customer@yahoo.com', 'customer', '2024-09-12 08:45:00');


-- Insert records into broadcast_messages table
INSERT INTO broadcast_messages (message_id, subject, message_body, sent_date, notes, message_type, customer_segment) 
VALUES 
(546, 'Service Update', 'We are introducing new features in our CRM system.', '2024-09-15 10:00:00', 'Check updates regularly', 'Update', 'All'),
(657, 'Reminder: Payment Due', 'Your payment is due in the next 5 days.', '2024-09-16 12:00:00', 'Sent to all active customers', 'Reminder', 'Returning');

-- Insert records into customer_complaints table
INSERT INTO customer_complaints (complaint_id, customer_id, complaint_subject, complaint_description, complaint_date, status, assigned_employee, notes) 
VALUES 
(201, 196, 'Login Issue', 'Customer cannot log into their account.', '2024-09-12 08:45:00', 'Pending', 'Nikki Hardy', 'Awaiting response from technical support'),
(901, 485, 'Incorrect Billing', 'Customer was charged twice for the same service.', '2024-09-13 09:15:00', 'Resolved', 'Lea Campbell', 'Refund processed.');

-- Insert records into messages table
INSERT INTO messages (message_id, sender_id, customer_id, subject, message_body, sent_date) 
VALUES 
(225, 192, 196, 'Welcome to CRM', 'Thank you for registering with our CRM system!', '2024-09-14 11:00:00'),
(680, 265, 485, 'Payment Reminder', 'Your payment is due soon. Please make sure to complete it in time.', '2024-09-14 12:30:00');

-- Insert records into tickets table
INSERT INTO tickets (ticket_id, customer_id, subject, description, priority, status, assigned_employee, created_at) 
VALUES 
(330, 196, 'Password Reset', 'Customer requested a password reset.', 'Medium', 'In Progress', 'Dylan Woodward', '2024-09-15 14:30:00'),
(094, 485, 'Account Deactivation', 'Customer requested account deactivation.', 'Low', 'Open', 'Joan Sampson', '2024-09-15 15:00:00');

-- Insert records into ticket_feedback table
INSERT INTO ticket_feedback (feedback_id, ticket_id, feedback, rating, feedback_date) 
VALUES 
(396, 330, 'Quick response and resolution.', 5, '2024-09-16 10:00:00'),
(027, 094, 'The deactivation process was smooth.', 4, '2024-09-16 11:00:00');
