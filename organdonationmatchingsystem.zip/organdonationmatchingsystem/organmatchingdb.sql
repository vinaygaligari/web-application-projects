DROP DATABASE IF EXISTS organmatchingdb;

CREATE DATABASE organmatchingdb;

USE organmatchingdb; 


CREATE TABLE donationbookings (
  BookingID int(11) NOT NULL AUTO_INCREMENT,
  DonorName varchar(255) NOT NULL,
  OrganOffered varchar(50) NOT NULL,
  RecipientName varchar(255) NOT NULL,
  RequiredOrgan varchar(50) NOT NULL,
  BookingDate timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  status varchar(20) DEFAULT 'Pending',
  PRIMARY KEY (BookingID)
);

CREATE TABLE donationrequests (
  RequestID int(11) NOT NULL AUTO_INCREMENT,
  RecipientName varchar(255) NOT NULL,
  RecipientAge int(11) NOT NULL,
  RecipientGender varchar(10) NOT NULL,
  RecipientPhone varchar(15) NOT NULL,
  RequiredOrgan varchar(50) NOT NULL,
  AdditionalInfo text,
  RequestDate timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (RequestID),
  UNIQUE KEY RecipientName (RecipientName)
);

CREATE TABLE donorregistration (
  id int(11) NOT NULL AUTO_INCREMENT,
  Name varchar(255) NOT NULL,
  Age int(11) NOT NULL,
  Gender enum('male','female','other') NOT NULL,
  Phone varchar(15) NOT NULL,
  Organ varchar(50) NOT NULL,
  Message text,
  RegistrationDate timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  availability enum('Available','Booked') NOT NULL DEFAULT 'Available',
  PRIMARY KEY (id),
  UNIQUE KEY Name (Name)
);

CREATE TABLE organdonationprograms (
  ProgramID int(11) NOT NULL AUTO_INCREMENT,
  ProgramName varchar(255) NOT NULL,
  Description text NOT NULL,
  StartDate date NOT NULL,
  EndDate date NOT NULL,
  Location varchar(255) NOT NULL,
  CreatedAt timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (ProgramID)
);

CREATE TABLE stories (
  StoryID int(11) NOT NULL AUTO_INCREMENT,
  Username varchar(100) NOT NULL,
  StoryContent text NOT NULL,
  EventDate date NOT NULL,
  StoryType enum('personal','recipient','donor','advocacy') NOT NULL,
  ContactMethod varchar(255) DEFAULT NULL,
  CreatedAt timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (StoryID)
);

CREATE TABLE users (
  UserID int(11) NOT NULL AUTO_INCREMENT,
  FullName varchar(100) DEFAULT NULL,
  Username varchar(50) DEFAULT NULL,
  Email varchar(100) DEFAULT NULL,
  Password varchar(255) DEFAULT NULL,
  Phone varchar(15) DEFAULT NULL,
  Address varchar(255) DEFAULT NULL,
  PRIMARY KEY (UserID),
  UNIQUE KEY Username (Username),
  UNIQUE KEY Email (Email)
);






INSERT INTO users (FullName, Username, Email, Password, Phone, Address)
VALUES
('Elmo Welch', 'elmo_welch54', 'elmo_welch54@mail.com', 'Password@123', '555-0101', '123 Elm St, Springfield, IL'),
('Alberta Reeves', 'alberta_reeves18', 'alberta_reeves18@hotmail.com', 'SecurePass!2024', '555-0202', '456 Maple Ave, Greenfield, OH'),
('Franklin Carey', 'franklin_carey28', 'franklin_carey28@gmail.com', 'Carey#2024', '555-0303', '789 Oak Rd, Shelbyville, IN');

INSERT INTO donationbookings (DonorName, OrganOffered, RecipientName, RequiredOrgan, BookingDate, status)
VALUES
('Elmo Welch', 'Kidney', 'Leticia Hanna', 'Heart', '2024-10-01 12:00:00', 'Pending'),
('Alberta Reeves', 'Liver', 'Gail Wells', 'Kidney', '2024-10-05 14:00:00', 'Confirmed'),
('Franklin Carey', 'Heart', 'Houston Schneider', 'Liver', '2024-11-10 10:00:00', 'Pending');

INSERT INTO donationrequests (RecipientName, RecipientAge, RecipientGender, RecipientPhone, RequiredOrgan, AdditionalInfo, RequestDate)
VALUES
('Leticia Hanna', 45, 'female', '555-0404', 'Heart', 'Urgent request for a heart transplant', '2024-10-01 12:00:00'),
('Gail Wells', 60, 'female', '555-0505', 'Kidney', 'Needs a kidney for dialysis', '2024-10-05 14:00:00'),
('Houston Schneider', 34, 'male', '555-0606', 'Liver', 'Liver failure due to alcohol consumption', '2024-11-10 10:00:00');

INSERT INTO donorregistration (Name, Age, Gender, Phone, Organ, Message, availability)
VALUES
('Elmo Welch', 34, 'male', '555-0101', 'Kidney', 'I am willing to donate a kidney', 'Available'),
('Alberta Reeves', 38, 'female', '555-0202', 'Liver', 'I am a registered liver donor', 'Available'),
('Franklin Carey', 45, 'male', '555-0303', 'Heart', 'I wish to donate my heart after death', 'Booked');

INSERT INTO organdonationprograms (ProgramName, Description, StartDate, EndDate, Location)
VALUES
('National Kidney Donation Campaign', 'A nationwide campaign to promote kidney donation awareness and registration.', '2024-10-01', '2024-11-01', 'Chicago, IL'),
('Heart Health Awareness Month', 'An initiative to raise awareness about heart disease and organ donations related to heart health.', '2024-11-01', '2024-11-30', 'New York, NY'),
('Liver Transplant Awareness Program', 'A program focusing on educating people about liver transplant procedures and donation.', '2024-12-01', '2024-12-31', 'Los Angeles, CA');

INSERT INTO stories (Username, StoryContent, EventDate, StoryType, ContactMethod)
VALUES
('elmo_welch54', 'I donated my kidney to a stranger, and it saved their life. The feeling was indescribable!', '2024-10-01', 'donor', 'email'),
('alberta_reeves18', 'I was a recipient of a liver transplant. Thanks to the donor, I can live a full life again!', '2024-10-05', 'recipient', 'phone'),
('franklin_carey28', 'This is my journey with waiting for a heart transplant. It’s been a long and emotional process.', '2024-11-10', 'personal', 'email');
