Step 1: 
Install Java 
https://www.youtube.com/watch?v=SQykK40fFds&t=267s

Step 2: 
Install XAMPP
https://www.youtube.com/watch?v=6WEhuHD184w

Step 3: 
After installation of XAMPP, follow the video below to run the web application and database files
https://drive.google.com/file/d/1S2eAeKR5KFzujN8rDKZWW4ZF4l1_JIim/view?usp=sharing

Step 4: 
Download following Mysql connector jar file and place it in C:\xampp\tomcat\lib
https://static.javatpoint.com/src/jdbc/mysql-connector.jar

Web application link
http://localhost:8080/organdonationmatching/userLogin.jsp

Web application explaination video link
https://drive.google.com/file/d/188TEver0Uxs6WDk1Gnlmvy8wTF_PLq4f/view?usp=drive_link


