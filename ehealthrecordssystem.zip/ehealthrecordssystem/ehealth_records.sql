CREATE DATABASE ehealth_records;

USE ehealth_records; 


CREATE TABLE `appointments` (
  `AppointmentID` int(11) NOT NULL AUTO_INCREMENT,
  `PatientName` varchar(100) NOT NULL,
  `AppointmentDate` date NOT NULL,
  `AppointmentTime` time NOT NULL,
  `Doctor` varchar(100) NOT NULL,
  `AdditionalMessage` text,
  `AppointmentStatus` varchar(50) NOT NULL DEFAULT 'Pending',
  `RequestedAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`AppointmentID`)
);

CREATE TABLE `patientcommunication` (
  `CommunicationID` int(11) NOT NULL AUTO_INCREMENT,
  `HealthcareExpertName` varchar(100) DEFAULT NULL,
  `PatientID` int(11) DEFAULT NULL,
  `Message` text,
  PRIMARY KEY (`CommunicationID`)
);

CREATE TABLE `patientinfo` (
  `PatientID` int(11) NOT NULL AUTO_INCREMENT,
  `IdentityNumber` varchar(20) DEFAULT NULL,
  `FirstName` varchar(50) DEFAULT NULL,
  `LastName` varchar(50) DEFAULT NULL,
  `DateOfBirth` date DEFAULT NULL,
  `Gender` enum('Male','Female','Other') DEFAULT NULL,
  `Address` varchar(100) DEFAULT NULL,
  `City` varchar(50) DEFAULT NULL,
  `State` varchar(50) DEFAULT NULL,
  `ZipCode` varchar(10) DEFAULT NULL,
  `PhoneNumber` varchar(15) DEFAULT NULL,
  `Email` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`PatientID`),
  UNIQUE KEY `IdentityNumber` (`IdentityNumber`)
);

CREATE TABLE `patientrecords` (
  `RecordID` int(11) NOT NULL AUTO_INCREMENT,
  `PatientID` int(11) DEFAULT NULL,
  `MedicalHistory` text,
  `Allergies` text,
  `Medications` text,
  `LastVisitDate` date DEFAULT NULL,
  `HospitalsVisited` text,
  `LabReports` text,
  `Appointments` text,
  `DiagnosisComments` text,
  PRIMARY KEY (`RecordID`)
);

CREATE TABLE `payments` (
  `PaymentID` int(11) NOT NULL AUTO_INCREMENT,
  `AppointmentID` int(11) NOT NULL,
  `DoctorName` varchar(100) NOT NULL,
  `HospitalName` varchar(100) NOT NULL,
  `PaymentAmount` decimal(10,2) NOT NULL,
  `PaymentDate` date NOT NULL,
  `PaymentMethod` varchar(50) NOT NULL,
  `PaymentStatus` varchar(50) NOT NULL DEFAULT 'Pending',
  PRIMARY KEY (`PaymentID`)
);

CREATE TABLE `userregistration` (
  `UserID` int(11) NOT NULL AUTO_INCREMENT,
  `Username` varchar(50) NOT NULL,
  `Email` varchar(100) NOT NULL,
  `Password` varchar(255) NOT NULL,
  `Mobile` varchar(15) NOT NULL,
  `City` varchar(50) NOT NULL,
  `Bio` text,
  PRIMARY KEY (`UserID`)
);



INSERT INTO appointments (PatientName, AppointmentDate, AppointmentTime, Doctor, AdditionalMessage, AppointmentStatus)
VALUES 
('Dexter Flowers', '2024-03-20', '10:00:00', 'Dr. Smith', 'Follow-up appointment', 'Pending'),
('Maria Padilla', '2024-03-21', '11:30:00', 'Dr. Johnson', 'Routine check-up', 'Pending'),
('Lauren Stokes', '2024-03-22', '14:00:00', 'Dr. Lee', 'Prescription renewal', 'Pending'),
('Felicia Russell', '2024-03-23', '09:15:00', 'Dr. Garcia', 'Dental cleaning', 'Pending'),
('Kristopher Payne', '2024-03-24', '16:45:00', 'Dr. Martinez', 'Vaccination', 'Pending');

INSERT INTO patientcommunication (HealthcareExpertName, PatientID, Message)
VALUES 
(NULL, 1, 'Need to discuss test results further'),
(NULL, 2, 'Follow-up on medication instructions'),
(NULL, 3, 'Appointment rescheduling request'),
(NULL, 4, 'Request for medical history update'),
(NULL, 5, 'Query about upcoming appointment');

INSERT INTO patientinfo (IdentityNumber, FirstName, LastName, DateOfBirth, Gender, Address, City, State, ZipCode, PhoneNumber, Email)
VALUES 
('12345', 'Dexter', 'Flowers', '1980-05-15', 'Male', '123 Main St', 'Cityville', 'NY', '12345', '123-456-7890', 'dexter@example.com'),
('23456', 'Maria', 'Padilla', '1975-09-23', 'Female', '456 Oak Ave', 'Townsville', 'CA', '67890', '456-789-0123', 'maria@example.com'),
('34567', 'Lauren', 'Stokes', '1992-03-08', 'Female', '789 Elm St', 'Villageton', 'TX', '34567', '789-012-3456', 'lauren@example.com'),
('45678', 'Felicia', 'Russell', '1988-11-17', 'Female', '321 Pine St', 'Hamletown', 'FL', '56789', '012-345-6789', 'felicia@example.com'),
('56789', 'Kristopher', 'Payne', '1973-07-29', 'Male', '987 Cedar Ave', 'Cityburgh', 'IL', '45678', '345-678-9012', 'kristopher@example.com');

INSERT INTO patientrecords (PatientID, MedicalHistory, Allergies, Medications, LastVisitDate, HospitalsVisited, LabReports, Appointments, DiagnosisComments)
VALUES 
(1, 'Past surgeries: Appendectomy in 2005', 'Penicillin', 'None', NULL, NULL, NULL, NULL, NULL),
(2, 'No significant medical history', 'None', 'Vitamin D supplements', NULL, NULL, NULL, NULL, NULL),
(3, 'Asthma history', 'Dust mites', 'Inhaler', NULL, NULL, NULL, NULL, NULL),
(4, 'Diabetes diagnosis', 'None', 'Insulin injections', NULL, NULL, NULL, NULL, NULL),
(5, 'Hypertension', 'None', 'Lisinopril', NULL, NULL, NULL, NULL, NULL);

INSERT INTO payments (AppointmentID, DoctorName, HospitalName, PaymentAmount, PaymentDate, PaymentMethod, PaymentStatus)
VALUES 
(1, 'Dr. Smith', 'City Hospital', 150.00, '2024-03-20', 'Credit Card', 'Pending'),
(2, 'Dr. Johnson', 'Town Clinic', 75.00, '2024-03-21', 'Cash', 'Pending'),
(3, 'Dr. Lee', 'Metropolitan Medical Center', 200.00, '2024-03-22', 'Debit Card', 'Pending'),
(4, 'Dr. Garcia', 'Dental Care Center', 120.00, '2024-03-23', 'Check', 'Pending'),
(5, 'Dr. Martinez', 'County Health Center', 50.00, '2024-03-24', 'Credit Card', 'Pending');
